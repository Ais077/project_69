import PostService from './API/PostService';
import React, {useState,useEffect} from 'react';
import './style/App.css';
import { useSelector, useDispatch } from "react-redux";
import instance from './API/PostService';

export default () => {
    const [Recipes,setRecipes] = useState([]);
    // const [Bascet,setBascet] = useState([]);
    const dispatch = useDispatch();
    const counter = useSelector(state => state.bascet)
    
    const AddInBascet = (e) => {
      dispatch({type: "ADD_IN_BUSCET", value: e})
    }

    const fetchRecipes = async () => {

      const recipes = await PostService.getAll();

      console.log(recipes)

      Object.entries(recipes).forEach(value => {
        setRecipes(...Recipes, value)
      // // const fetchedOrders = Object.keys(recipes).map(value => {
      // //   return {...recipes, value};
      //   const fetchedOrders = Object.keys(recipes.data).map(id => {
      //     return {...recipes.data[id], id};
        
      });
      // setRecipes(fetchedOrders)
    }
    console.log(Recipes);
    
  useEffect(() => {
    fetchRecipes();
  }, [])

  return (
      <section className = 'list'>
      <h1>Блюда</h1>
      {
        Recipes.map(recipe=>{
          return(
            <section key={recipe} className='item'>
              <h3>{recipe.title}</h3>
              <img src={recipe.img} alt = "img" />
              <pre>{recipe.price + " " + "тг."}</pre>
              <button onClick={() => {AddInBascet({title: recipe.title, price: recipe.price, img: recipe.img})}}>в корзину</button>
            </section>
          )
        })
      }
      </section>
  );
}