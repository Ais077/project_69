let but = {
    buttons:[
        {val:"1"},{val:"2"},{val:"3"},{val:"4"},{val:"5"},
        {val:"6"},{val:"7"},{val:"8"},{val:"<"},{val:"9"},{val:"0"},{val:"E"},
    ]
}


// const addNumber = (e)=>{
//     let value = (e.target.value);
//     let number = N(value)

//     dispatchEvent()
// }

export default but;